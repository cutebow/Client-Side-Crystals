package me.clientsidecrystals.core;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import me.clientsidecrystals.compat.CrystalAnchorCounterCompat;
import me.clientsidecrystals.compat.FlashbackCompat;
import me.clientsidecrystals.compat.ReplayCrystalPayload;
import me.clientsidecrystals.config.ConfigManager;
import me.clientsidecrystals.mixin.EntityAgeAccessor;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1511;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.UUID;

public final class CrystalPredictor {
    private static final class_310 client = class_310.method_1551();
    private static final Long2ObjectOpenHashMap<LocalCrystal> crystals = new Long2ObjectOpenHashMap<>();
    private static final Set<class_1511> localEntities = Collections.newSetFromMap(new IdentityHashMap<>());

    private static int tick;
    private static int mainSwings;
    private static int offSwings;
    private static int mainSwingExpiry;
    private static int offSwingExpiry;

    private CrystalPredictor() {
    }

    public static void setEnabled(boolean enabled) {
        ConfigManager.config.instantEnabled = enabled;
        if (!enabled) {
            clearAll();
        }
    }

    public static boolean isEnabled() {
        return ConfigManager.config.instantEnabled;
    }

    public static void handleReplayCrystalPayload(ReplayCrystalPayload payload) {
        if (payload.action() == ReplayCrystalPayload.Action.SPAWN) {
            spawnLocal(payload.pos(), Math.max(1, payload.ttlTicks()), false, true);
        } else {
            removeLocal(payload.pos().method_10063(), false);
        }
    }

    public static void clientTick() {
        if (!isEnabled() || spectatorBlocked()) {
            if (!crystals.isEmpty()) {
                clearAll();
            }
            return;
        }

        if (client.field_1687 == null) {
            return;
        }

        tick++;
        expireSwings();

        long[] keys = crystals.keySet().toLongArray();
        for (long key : keys) {
            LocalCrystal local = crystals.get(key);
            class_1511 crystal = local.entity();

            // flashback uses its own replay tick here
            int clock = local.replayClock() ? FlashbackCompat.replayTick() : tick;
            if (crystal.method_31481() || !crystal.method_5805() || clock >= 0 && clock >= local.expiresTick()) {
                removeLocal(key, false);
                continue;
            }

            class_2338 pos = class_2338.method_10092(key);
            crystal.method_5808(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, 0.0F, 0.0F);
            crystal.method_6839(false);
            crystal.field_5960 = true;
        }

        if (!FlashbackCompat.isReplayActive() && client.field_1690.field_1886.method_1434()) {
            removeCrosshairCrystal();
        }
    }

    public static void onUseBlock(class_1268 hand, class_3965 hit) {
        if (!isEnabled() || FlashbackCompat.isReplayActive() || spectatorBlocked() || client.field_1687 == null) {
            return;
        }

        if (hit.method_17783() != class_239.class_240.field_1332 || hit.method_17780() == class_2350.field_11033) {
            return;
        }

        class_2338 base = hit.method_17777();
        if (!canPlaceOn(base)) {
            return;
        }

        class_2338 crystalPos = base.method_10084();
        if (crystals.containsKey(crystalPos.method_10063()) || hasRealCrystal(crystalPos)) {
            return;
        }

        spawnLocal(crystalPos);
        swing(hand);
    }

    public static void onEntityLoaded(class_1297 entity) {
        if (!isEnabled() || spectatorBlocked() || !(entity instanceof class_1511 realCrystal)) {
            return;
        }

        // keep fake crystal until real spawns in
        LocalCrystal local = detach(realCrystal.method_24515().method_10063());
        if (local == null) {
            return;
        }

        class_1511 fakeCrystal = local.entity();
        if (fakeCrystal.method_31481() || !fakeCrystal.method_5805()) {
            SeamlessCrystalBridge.clear(fakeCrystal.method_5628());
            return;
        }

        if (ConfigManager.config.seamlessEnabled && !client.field_1690.field_1886.method_1434()) {
            float entityAge = ((EntityAgeAccessor) (Object) fakeCrystal).csc$getAge();
            float renderedAge = SeamlessCrystalBridge.takeRenderedAge(fakeCrystal.method_5628(), entityAge);
            SeamlessCrystalBridge.link(realCrystal.method_5628(), renderedAge);
        } else {
            SeamlessCrystalBridge.clear(fakeCrystal.method_5628());
        }

        fakeCrystal.method_31472();
    }

    public static void onEntityUnloaded(class_1297 entity) {
        if (!(entity instanceof class_1511 crystal)) {
            return;
        }

        SeamlessCrystalBridge.clear(crystal.method_5628());
        removeLocal(crystal.method_24515().method_10063(), !FlashbackCompat.isReplayActive());
    }

    public static boolean isLocalCrystal(class_1297 entity) {
        return entity instanceof class_1511 crystal && localEntities.contains(crystal);
    }

    public static boolean consumeServerSwingSuppression(class_1268 hand) {
        if (!ConfigManager.config.instantArmSwing) {
            return false;
        }

        if (hand == class_1268.field_5808) {
            if (mainSwings == 0 || tick > mainSwingExpiry) {
                mainSwings = 0;
                return false;
            }
            mainSwings--;
            return true;
        }

        if (offSwings == 0 || tick > offSwingExpiry) {
            offSwings = 0;
            return false;
        }
        offSwings--;
        return true;
    }

    public static void clearAll() {
        for (long key : crystals.keySet().toLongArray()) {
            removeLocal(key, false);
        }
        localEntities.clear();
        mainSwings = 0;
        offSwings = 0;
        mainSwingExpiry = 0;
        offSwingExpiry = 0;
        SeamlessCrystalBridge.clearAll();
    }

    private static void removeCrosshairCrystal() {
        if (!(client.field_1765 instanceof class_3966 hit)) {
            return;
        }
        if (!(hit.method_17782() instanceof class_1511 crystal) || !localEntities.contains(crystal)) {
            return;
        }

        removeLocal(crystal.method_24515().method_10063(), true);
        CrystalAnchorCounterCompat.recordCrystalBreak(crystal.method_5628(), crystal.method_5667());
    }

    private static void spawnLocal(class_2338 pos) {
        spawnLocal(pos, Math.max(2, ConfigManager.config.predictionTimeoutTicks), true, false);
    }

    private static void spawnLocal(class_2338 pos, int ttl, boolean record, boolean replayClock) {
        class_638 world = client.field_1687;
        if (world == null) {
            return;
        }

        long key = pos.method_10063();
        removeLocal(key, false);

        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264();
        double z = pos.method_10260() + 0.5;
        class_1511 crystal = new class_1511(world, x, y, z);
        crystal.method_5826(UUID.randomUUID());
        crystal.method_6839(false);
        crystal.field_5960 = true;
        crystal.method_5808(x, y, z, 0.0F, 0.0F);
        world.method_53875(crystal);

        int lifetime = Math.max(1, ttl);
        int clock = tick;
        boolean useReplayClock = false;
        if (replayClock) {
            int replayTick = FlashbackCompat.replayTick();
            if (replayTick >= 0) {
                clock = replayTick;
                useReplayClock = true;
            }
        }
        crystals.put(key, new LocalCrystal(crystal, clock + lifetime, useReplayClock));
        localEntities.add(crystal);

        if (record) {
            FlashbackCompat.recordCrystalSpawn(pos, lifetime);
        }
    }

    private static void swing(class_1268 hand) {
        if (!ConfigManager.config.instantArmSwing || client.field_1724 == null) {
            return;
        }

        client.field_1724.method_23667(hand, false);
        int expiry = tick + Math.max(4, ConfigManager.config.predictionTimeoutTicks + 2);

        if (hand == class_1268.field_5808) {
            mainSwings++;
            mainSwingExpiry = Math.max(mainSwingExpiry, expiry);
        } else {
            offSwings++;
            offSwingExpiry = Math.max(offSwingExpiry, expiry);
        }
    }

    private static void expireSwings() {
        if (mainSwings > 0 && tick > mainSwingExpiry) {
            mainSwings = 0;
        }
        if (offSwings > 0 && tick > offSwingExpiry) {
            offSwings = 0;
        }
    }

    private static boolean spectatorBlocked() {
        return client.field_1724 != null && client.field_1724.method_7325() && !FlashbackCompat.isReplayActive();
    }

    private static boolean hasRealCrystal(class_2338 pos) {
        class_638 world = client.field_1687;
        if (world == null) {
            return false;
        }

        return !world.method_18023(
                class_1299.field_6110,
                crystalBox(pos),
                crystal -> !localEntities.contains(crystal)
        ).isEmpty();
    }

    private static boolean canPlaceOn(class_2338 base) {
        class_638 world = client.field_1687;
        if (world == null) {
            return false;
        }

        class_2680 state = world.method_8320(base);
        if (!state.method_27852(class_2246.field_10540) && !state.method_27852(class_2246.field_9987)) {
            return false;
        }

        class_2338 crystalPos = base.method_10084();
        if (!world.method_8320(crystalPos).method_26215()) {
            return false;
        }

        return world.method_8333(
                null,
                crystalBox(crystalPos),
                entity -> entity.method_5805() && !isLocalCrystal(entity)
        ).isEmpty();
    }

    private static class_238 crystalBox(class_2338 pos) {
        class_243 center = class_243.method_24953(pos);
        return new class_238(center.method_1031(-0.5, -0.5, -0.5), center.method_1031(0.5, 1.5, 0.5));
    }

    private static LocalCrystal detach(long key) {
        LocalCrystal local = crystals.remove(key);
        if (local != null) {
            localEntities.remove(local.entity());
        }
        return local;
    }

    private static void removeLocal(long key, boolean record) {
        LocalCrystal local = detach(key);
        if (local == null) {
            return;
        }

        if (record) {
            FlashbackCompat.recordCrystalRemove(class_2338.method_10092(key));
        }

        class_1511 crystal = local.entity();
        SeamlessCrystalBridge.clear(crystal.method_5628());
        if (crystal.method_5805()) {
            crystal.method_31472();
        }
    }

    private record LocalCrystal(class_1511 entity, int expiresTick, boolean replayClock) {
    }
}
