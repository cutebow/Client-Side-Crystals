package me.clientsidecrystals.core;

import me.clientsidecrystals.compat.FlashbackCompat;
import me.clientsidecrystals.config.ConfigManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_638;

public final class ClientHooks implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FlashbackCompat.init();
        ConfigManager.load();

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world instanceof class_638 && player.method_5998(hand).method_31574(class_1802.field_8301)) {
                CrystalPredictor.onUseBlock(hand, hit);
            }
            return class_1269.field_5811; // geeg
        });

        ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> CrystalPredictor.onEntityLoaded(entity));
        ClientEntityEvents.ENTITY_UNLOAD.register((entity, world) -> CrystalPredictor.onEntityUnloaded(entity));

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            CrystalPredictor.clientTick();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> CrystalPredictor.clearAll());
    }
}
