package me.clientsidecrystals.compat;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ReplayCrystalPayload(Action action, class_2338 pos, int ttlTicks) implements class_8710 {
    public static final class_9154<ReplayCrystalPayload> ID =
            new class_9154<>(class_2960.method_60655("clientsidecrystals", "flashback_crystal"));
    public static final class_9139<class_9129, ReplayCrystalPayload> CODEC =
            class_8710.method_56484(ReplayCrystalPayload::write, ReplayCrystalPayload::read);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }

    private static ReplayCrystalPayload read(class_9129 buffer) {
        return new ReplayCrystalPayload(
                Action.fromId(buffer.readByte()),
                class_2338.field_48404.decode(buffer),
                buffer.method_10816()
        );
    }

    private static void write(ReplayCrystalPayload payload, class_9129 buffer) {
        buffer.method_52997(payload.action().id());
        class_2338.field_48404.encode(buffer, payload.pos());
        buffer.method_10804(Math.max(0, payload.ttlTicks()));
    }

    public enum Action {
        SPAWN((byte) 0),
        REMOVE((byte) 1);

        private final byte id;

        Action(byte id) {
            this.id = id;
        }

        public byte id() {
            return id;
        }

        private static Action fromId(byte id) {
            return switch (id) {
                case 0 -> SPAWN;
                case 1 -> REMOVE;
                default -> throw new IllegalArgumentException("Unknown replay crystal action id: " + id);
            };
        }
    }
}
