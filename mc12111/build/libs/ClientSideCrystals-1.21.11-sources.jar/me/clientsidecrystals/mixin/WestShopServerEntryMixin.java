package me.clientsidecrystals.mixin;

import me.clientsidecrystals.util.WestShopNameStyle;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4267;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_4267.class_4270.class)
public abstract class WestShopServerEntryMixin {
    @Shadow
    @Final
    private class_642 server;

    @Redirect(
            method = "render(Lnet/minecraft/client/gui/DrawContext;IIZF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)V"
            )
    )
    private void csc$drawServerName(
            class_332 context,
            class_327 renderer,
            String text,
            int x,
            int y,
            int color
    ) {
        if (WestShopNameStyle.isWestShop(server.field_3761)) {
            WestShopNameStyle.drawAnimatedName(context, renderer, x, y);
            return;
        }
        if (WestShopNameStyle.isNaPvP(server.field_3761)) {
            WestShopNameStyle.drawAnimatedNaPvPName(context, renderer, text, x, y);
            return;
        }

        context.method_25303(renderer, text, x, y, color);
    }
}
