package me.clientsidecrystals.mixin;

import me.clientsidecrystals.config.ConfigManager;
import me.clientsidecrystals.core.CrystalPredictor;
import me.clientsidecrystals.core.SeamlessCrystalBridge;
import net.minecraft.class_10014;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_1511;
import net.minecraft.class_1921;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_892;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.WeakHashMap;

@Mixin(class_892.class)
public abstract class EndCrystalEntityRendererSeamlessMixin {
    @Unique
    private static final Map<class_10014, Boolean> csc$localStates = new WeakHashMap<>();

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void csc$trackState(
            class_1511 entity,
            class_10014 state,
            float tickDelta,
            CallbackInfo ci
    ) {
        boolean local = CrystalPredictor.isLocalCrystal(entity);
        csc$localStates.put(state, local);

        if (local) {
            SeamlessCrystalBridge.recordRenderedAge(entity.method_5628(), state.field_53328);
            return;
        }

        if (ConfigManager.config.instantEnabled && ConfigManager.config.seamlessEnabled) {
            state.field_53328 = SeamlessCrystalBridge.apply(entity.method_5628(), state.field_53328);
        }
    }

    @Redirect(
            method = "render(Lnet/minecraft/client/render/entity/state/EndCrystalEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"
            )
    )
    private void csc$redirectSubmitModel(
            class_11659 queue,
            class_3879<Object> model,
            Object stateObject,
            class_4587 matrices,
            class_1921 renderLayer,
            int light,
            int overlay,
            int outlineColor,
            class_11683.class_11792 crumblingOverlay
    ) {
        if (stateObject instanceof class_10014 state
                && csc$localStates.getOrDefault(state, false)
                && ConfigManager.config.colorFakeCrystal) {
            queue.method_73490(
                    model,
                    stateObject,
                    matrices,
                    renderLayer,
                    light,
                    overlay,
                    ConfigManager.config.fakeCrystalColor,
                    null,
                    outlineColor,
                    crumblingOverlay
            );
            return;
        }

        queue.method_73489(
                model,
                stateObject,
                matrices,
                renderLayer,
                light,
                overlay,
                outlineColor,
                crumblingOverlay
        );
    }
}
