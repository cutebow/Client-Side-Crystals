package me.clientsidecrystals.mixin;

import me.clientsidecrystals.core.CrystalPredictor;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityInstantSwingMixin {
    @Inject(method = "swingHand(Lnet/minecraft/util/Hand;Z)V", at = @At("HEAD"), cancellable = true)
    private void csc$cancelDelayedServerSwing(class_1268 hand, boolean fromServerPlayer, CallbackInfo ci) {
        if (!fromServerPlayer || (Object) this != class_310.method_1551().field_1724) {
            return;
        }

        if (CrystalPredictor.consumeServerSwingSuppression(hand)) {
            ci.cancel();
        }
    }
}
